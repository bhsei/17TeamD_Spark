'use strict';
//queue length是当前queue的长度，queueLength是queue的固定长度
const should = require('should');
const pedding = require('pedding');
const asyncLimit = require('../lib/asyncLimit');

describe('asyncLimit', function () {
  var async = function (ms, callback) {
    setTimeout(function () {
      callback(null, {});
    }, ms);
  };

  it('constructor', function () {
    var asy = new asyncLimit(10);
    asy.limit.should.be.equal(10);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    asy.options.disabled.should.be.equal(false);
  });
//测试disabled,传入参数为limit-10,disabled-true,则options中的disabled值应为True
  it('constructor disabled', function () {
    var asy = new asyncLimit(10, true);
    asy.limit.should.be.equal(10);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    asy.options.disabled.should.be.equal(true);
  });
//limit为0，方法为异步，调用70行，直接返回
  it('constructor limit less than 1', function (done) {
    var asy = new asyncLimit(0);
    asy.push(async, 10, function () {
      asy.active.should.be.equal(0);
      done();
    });
    asy.active.should.be.equal(0);
  });
//在下一个结点limit比1小的情况，不懂什么用意
  it('constructor limit less than 1 for nextTick', function (done) {
    var asy = new asyncLimit(0);
    asy.push(process.nextTick, function () {
      asy.active.should.be.equal(0);
      done();
    });
    asy.active.should.be.equal(0);
  });
//disabled是true的情况，禁用限流
  it('constructor disabled is true', function (done) {
    var asy = new asyncLimit(10, true);
    asy.push(async, 10, function () {
      asy.active.should.be.equal(0);
      done();
    });
    asy.active.should.be.equal(0);
  });
//测试Push函数,运行到nexy()，active++
  it('push', function (done) {
    var asy = new asyncLimit(5);
    asy.limit.should.be.equal(5);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    asy.push(async, 10, function () {
      asy.active.should.be.equal(0);
      done();
    });
    asy.active.should.be.equal(1);
  });
//测试异步Push
  it('push, async with this', function (done) {
    var asy = new asyncLimit(5);
    asy.limit.should.be.equal(5);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    var context = {value: 10};
    context.async = function (callback) {
      this.value--;
      console.log('this:',this.value);
      var that = this;
      process.nextTick(function() {
        callback(that.value);
        // console.log('that:',that.value);
      });
    };

    asy.push(context.async.bind(context), function () {
      asy.active.should.be.equal(0);
      done();
    });
    asy.active.should.be.equal(1);
  });
//push时active的数量不应超过limit
  it('push, active should not be above limit', function (done) {
    var limit = 5;
    var asy = new asyncLimit(limit);
    asy.limit.should.be.equal(limit);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    var counter = 10;
    for (var i = 0; i < counter; i++) {
      var pushValue = 1 + Math.round(Math.random() * 10);
      asy.push(async, pushValue, function () {
        // console.log('push:',pushValue);
        // console.log('active:',asy.active);
        asy.active.should.not.be.above(limit);
        counter--;
        if (counter === 0) {
          done();
        }
      });
      asy.active.should.not.be.above(limit);
    }
  });
//在禁用限流的情况下，active不应超过limit
  it('push, disabled, active should not be above limit', function (done) {
    var limit = 5;
    var asy = new asyncLimit(limit, true);
    asy.limit.should.be.equal(limit);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    var counter = 10;
    for (var i = 0; i < counter; i++) {
      var pushValue = 10 + Math.round(Math.random() * 10);
      asy.push(async, pushValue, function () {
        // console.log('push:',pushValue);
        // console.log('active:',asy.active);
        asy.active.should.be.equal(0);
        counter--;
        if (counter === 0) {
          done();
        }
      });
      asy.active.should.be.equal(0);
    }
  });
//测试full
  it('full event should fired when above limit', function (done) {
    var limit = 5;
    var asy = new asyncLimit(limit);
    asy.limit.should.be.equal(limit);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    var counter = 0;
    asy.on('full', function (length) {
      length.should.above(1);
      // console.log(length.should.above(1));
      counter++;
      console.log('length:',length,'counter:',counter);
    });

    var noop = function () {};
    for (var i = 0; i < 100; i++) {
      asy.push(async, 10, noop);
      // console.log('queue length:',asy.queue.length);
    }
    counter.should.above(0);
    done();
  });
//没有回调，不影响执行
  it('should support without callback', function (done) {
    var limit = 5;
    var asy = new asyncLimit(limit);
    asy.limit.should.be.equal(limit);
    asy.queue.should.have.length(0);
    asy.active.should.be.equal(0);
    asy.push(async, 10);
    // console.log(asy.active);
    asy.active.should.be.equal(1);
    done();
  });
//是否能得到TooMuchAsyncCallError,拒绝模式，排队超过限制值时，新来的调用将会得到`TooMuchAsyncCallError`异常
//   it('should get TooMuchAsyncCallError', function (done) {
//     done = pedding(5, done);
//     var limit = 2;
//     var asy = new asy(limit, {
//       refuse: true
//     });
//     asy.limit.should.be.equal(limit);
//     asy.queue.should.have.length(0);
//     asy.active.should.be.equal(0);
//     for (var i = 0; i < 4; i++) {
//       asy.push(async, 10, function (err) {
//         console.log('active:',asy.active);
//         should.not.exist(err);
//         done();
//       });
//     }
//     asy.push(async, 10, function (err) {
//       console.log('active:',asy.active);
//       should.exist(err);
//       done();
//     });
//     asy.active.should.be.equal(2);
//   });
//在ratio！=1的情况下测试TooMuchAsyncCallError
//   it('should get TooMuchAsyncCallError with ratio', function (done) {
//     done = pedding(7, done);
//     var limit = 2;
//     var asy = new asy(limit, {
//       refuse: true,
//       ratio: 2
//     });
//     asy.limit.should.be.equal(limit);
//     asy.queue.should.have.length(0);
//     asy.active.should.be.equal(0);
//     for (var i = 0; i < 2; i++) {
//       asy.push(async, 10, function (err) {
//         should.not.exist(err);
//         done();
//       });
//     }
//     asy.queue.should.have.length(0);
//     for (i = 0; i < 4; i++) {
//       asy.push(async, 10, function (err) {
//         should.not.exist(err);
//         done();
//       });
//     }
//     asy.queue.should.have.length(4);
//     //超过队列长度，应该抛出错误
//     asy.push(async, 10, function (err) {
//       should.exist(err);
//       done();
//     });
//     asy.active.should.be.equal(2);
//     asy.queue.should.have.length(4);
//   });
//测试超时
  it('should get TimeoutError', function (done) {
    done = pedding(3, done);

    var _async = function _async(ms, callback) {
      setTimeout(function () {
        callback(null, {ms: ms});
        // console.log(ms)
      }, ms);
    };
    var _async2 = function _async(ms, callback) {
      setTimeout(function () {
        callback(new Error('Timeout'));
      }, ms);
    };
    var asy = new asyncLimit(10, {
      timeout: 10
    });
    asy.on('outTime', function (err) {
      should.exist(err);
      done();
    });
//5<10不报错
    asy.push(_async, 5, function (err, data) {
      should.not.exist(err);
      should.exist(data);
      data.should.have.property('ms', 5);
      done();
    });
//15>10报错
    asy.push(_async2, 15, function (err) {
      should.exist(err);
      err.name.should.eql('TimeoutError');
      err.message.should.eql('10ms timeout');
      err.data.should.have.property('name', '_async');
      err.data.should.have.property('method');
      err.data.args.should.eql([15]);
      done();
    });
  });
});
