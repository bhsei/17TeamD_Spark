/**
 * 静态文件加载
 */

const fs     = require('fs');
const path   = require('path');
const Utils  = require('./Utils');

/**
 * 辅助加载函数，根据路径加载文件
 * @private
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 * @param {string} [filename] 静态文件的路径
 * @param {string} [type] 读取的文件类型
 */

var readStaticFile = function(req, res, filename, type) {
    fs.readFile(filename, function(err, data) {
       if(err) {
            Utils.handleError(err, type);
            res.writeHead(404);
            res.end("We Got A Problem：File Not Found");
       } else {
            res.writeHead(200);
            res.end(data);
       }
    });
}

/**
 * 加载静态文件，css、js等
 * @public
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 * @param {string} [pathname] 静态文件的路径
 */

exports.loadFile = function(req, res, pathname) {
    var pathname = '../../public'+ pathname.toString();
    var filename = path.join(__dirname, pathname);
    readStaticFile(req, res, filename, "Read Static File");
}


/**
 * 加载主页，主页固定为index.html
 * @public
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 * @param {string} [pathname] 静态文件的路径
 */

exports.index = function(req, res) {
     var filename = path.join(__dirname, '../../public/html/dnsQuery.html');
     readStaticFile(req, res, filename, "File Read In Home Page")
}

module.exports = exports;
