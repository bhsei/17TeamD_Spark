/**
 * 工具类，提供一些通用处理
 */

/* 用于 console 输出文字的颜色*/
const colors = require( "colors")

/**
 * 统一处理所有的错误
 * @public
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 */

exports.handleError = function(err, type) {
    var time = new Date();
    var msg = "-----------------------------------------------" + "\n" +
              "Time: " + time.toUTCString() + "\n" +
              "Type: " + type + "\n" +
              "-----------------------------------------------" + "\n" +
              err + '\n';
    console.log(msg.red);
}

/**
 * 统一处理进行控制台记录
 * @public
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 */

exports.record = function(data) {
    var time = new Date();
    var msg = "Time: " + time.toUTCString() + "\n" + data + '\n';
    console.log(msg.green);
}

module.exports = exports;
