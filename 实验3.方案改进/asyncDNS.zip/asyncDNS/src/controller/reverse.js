/**
 * Created by skyxi on 2017/5/16.
 */
/**
 * DNS解析
 */

const DNS = require('dns')
const Url = require('url');
const QueryString = require("querystring");
const Utils = require('./Utils');
const asyncLimit = require('./../lib/asyncLimit');

/**
 * 对域名进行解析，返回获取到的IP地址
 * @public
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 */
var async  = new asyncLimit(100);
exports.parse = function(req, res) {

    // 对 request 的 url 进行解析，并提取GET请求的参数

    var url_query = Url.parse(req.url).query;
    var query = QueryString.parse(url_query);

    /*DNS.resolve4(query['hostname'], function(err, addresses) {
     if (err) {
     Utils.handleError(err, "DNS Parse Error");
     res.writeHead(400);
     res.end();
     }
     else {
     res.writeHead(200);
     res.end(JSON.stringify(addresses));
     }
     });*/
    DNS.reverse('119.75.217.109',(err,hostnames)=>{
        console.log(hostnames);//结果为[ 'public1.114dns.com' ]
    });
    async.push(DNS.lookupService,query['ip'],80,function(err, hostname,service) {
        console.log(hostname);
        console.log(service);
        if (err) {
            console.log(err);
            Utils.handleError(err, "reverse Parse Error");
            res.writeHead(400);
            res.end();
        }
        else {
            res.writeHead(200);
            res.end(JSON.stringify(addresses));
        }
    });
}



module.exports = exports;
