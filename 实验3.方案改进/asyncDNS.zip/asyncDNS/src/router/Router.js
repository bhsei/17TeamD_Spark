/**
 * 路由
 */

const Url        = require('url');
const ipv4 = require('./../controller/ipv4.js');
const ipv6 = require('./../controller/ipv6.js');
const reverse = require('./../controller/reverse.js');
const StaticFile = require('./../controller/StaticFile.js')
const Utils      = require('./../controller/Utils.js')

/**
 * 路由模块，根据pathname进行不同处理
 * @private
 * @param {object} [req] HTTP请求的request
 * @param {object} [res] HTTP请求的response
 */

exports.router = function(req, res) {
    var url      = Url.parse(req.url);
    var pathname = url.pathname;

    Utils.record("Path: " + url.path);

    switch(pathname) {
        case '/ipv4' :
            ipv4.parse(req, res, pathname);
            break;
        case '/ipv6':
            ipv6.parse(req, res, pathname);
            break;
        case '/reverse':
            reverse.parse(req, res, pathname);
            break;
        case '/':
        case '/index':
            StaticFile.index(req, res);
            break;
        default:
            StaticFile.loadFile(req, res, pathname);
    }
}


module.exports = exports;
