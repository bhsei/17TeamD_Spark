
const Http = require('http');
const Router = require('./src/router/Router.js');


const config = {
    port: 3333
}
Http.createServer(function(req, res) {

    Router.router(req, res);

}).listen(config.port);

console.log("-----------------------------------------------");
console.log("Listen at");
console.log("http:\/\/localhost:" + config.port);
console.log("-----------------------------------------------");
