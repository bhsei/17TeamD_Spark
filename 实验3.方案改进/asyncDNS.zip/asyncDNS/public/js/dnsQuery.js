
/**
 * 用Promise封装的Ajax请求，默认异步请求，默认使用JSON进行前后端通信
 * @param {string} [url] api的请求参数
 * @param {string} [method] api的请求方法
 */

var promiseAjax = function(url, method) {
    return new Promise(function(resolve, reject) {
        if(!window.XMLHttpRequest) {
            alert("请使用Chrome、Safari、Firefox等浏览器");
        } else {
            var xhr = new XMLHttpRequest();
            xhr.open(method, url, true);
            xhr.setRequestHeader("Accept", "application/json");
            xhr.onreadystatechange = function() {
                if(this.readyState != 4)
                    return;
                if(this.status == 200) {
                    resolve(this.response);
                } else {
                    reject(new Error(this.statusText));
                }
            }
            xhr.send();
        }
    });
}

//去除url里的http:
var httpReplace=function (hostname) {
    
    return hostname.replace(/http:\/\//g, "");
}

//去除url里的https：
var httpsReplace=function (hostname){
    
    return hostname.replace(/https:\/\//g, "");
}

window.onload = function() {

    var dns             = document.getElementById('dns_query_submit'),
        hostname_input  = document.getElementById('hostname'),
        result          = document.getElementById('dns_result');

    dns.addEventListener('click', function() {
        var hostname        = hostname_input.value.toString(),
            method          = "GET",
            url;

        /* 去除 http:// 和 https:// */
        /*hostname = hostname.replace(/http:\/\//g, "");
        hostname = hostname.replace(/https:\/\//g, "");*/
        hostname=httpReplace(hostname);
        hostname=httpsReplace(hostname);

        // 内容不允许为空
        if(!hostname) {
            result.innerHTML = "请输入域名";
            result.style.color = "red";
            return;
        }

        var select=document.getElementById("p_hostname");
        var selectValue=select.value;
        console.log(selectValue);

        switch(Number(selectValue)){
            case 1:
                url='/ipv4?hostname='+hostname;
                break;
            case 2:
                url='/ipv6?hostname='+hostname;
                break;
            case 3:
                url='/reverse?ip='+hostname;
        }

       // url = '/dns?hostname=' + hostname;

        promiseAjax(url, method)
            .then(function(data) {

                var data = JSON.parse(data);
                if(data.length == 0) {
                    result.innerHTML = "查询结果：未查询到结果";
                    result.style.color = "white";
                    return ;
                }
                if(data[0]) {
                    result.innerHTML = "查询结果：" + data[0];
                    result.style.color = "white";
                }
            })
            .catch(function(err) {

                switch(Number(selectValue)){
                    case 1:
                        result.innerHTML = "查询结果：请输入正确的ipv4域名";
                        break;
                    case 2:
                        result.innerHTML = "查询结果：请输入正确的ipv6域名";
                        break;
                    case 3:
                        result.innerHTML = "查询结果：请输入正确的ip";
                }

                
                result.style.color = "red";
            });
    });

    // 输入时，清除上次结果
    hostname_input.addEventListener('focus', function() {
        result.innerHTML = "";
        hostname_input.value = "";
    });

    /* 监听 回车键*/
    document.onkeydown = function(event) {
        if(event.keyCode == 13) {
            dns.click();
        }
    }

}
