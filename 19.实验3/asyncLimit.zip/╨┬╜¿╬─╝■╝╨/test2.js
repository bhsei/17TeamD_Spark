var asyncLimit = require('./lib/asyncLimit');

var async  = new asyncLimit(20);

var test=function (callback) {
    console.log("A");
    callback();
}

for(var i=0;i<100;i++)
{
    async.push(test, function (data) {
    });
}
async.on('full',function (length) {
    console.log('调用已满，队列长'+length);
})
